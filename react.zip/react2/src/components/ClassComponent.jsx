import React from "react";

class ClassComponent extends React.Component {
    render() {
        return (
            <div>
                <h4>클래스 컴포넌트 방식으로 컴포넌트 생성</h4>
                <p>클래스 컴포넌트로 생성한 자식 컴포넌트입니다.</p>
            </div>
        );
    }
}

export default ClassComponent;