function Footer() {
    return (
        <footer>
            <p>Footer</p>
        </footer>
    );
}

export default Footer;