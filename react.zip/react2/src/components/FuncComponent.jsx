function FuncComponent() {
    return (
        <div>
            <h1>함수 컴포넌트 방식으로 컴포넌트 생성</h1>
            <p>함수 컴포넌트로 생성한 자식 컴포넌트</p>
        </div>
    );
}

export default FuncComponent;