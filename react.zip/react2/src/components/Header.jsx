function Header(props) {
    return (
        <header>
            <h1>{props.title}</h1>
            <h3>header 영역입니다.</h3>
        </header>
    );
}

export default Header;