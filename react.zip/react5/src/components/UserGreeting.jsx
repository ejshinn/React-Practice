function UserGreeting() {
    return <h1>방문해 주셔서 감사합니다.</h1>;
}

export default UserGreeting;