function GuestGreeting() {
    return <h1>회원가입을 해주세요.</h1>;
}

export default GuestGreeting;